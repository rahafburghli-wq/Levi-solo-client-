# Levi Solo Client — Minecraft 1.26.52 / 26.52 feature status

**Compatibility target:** the user's reported game version is `1.26.52`; Mojang's official changelog labels the corresponding release `26.52`. The manifest build patterns target both naming forms. Native symbol compatibility remains unverified.

The following is the complete requested catalog. The source attempts to register each name in the in-game Mod Menu when the native library is built and loaded; that menu registration has not been tested. Each placeholder defaults OFF and activation is refused.

| Category | Feature | Current state |
|---|---|---|
| Combat | KillAura / Forcefield | Catalog placeholder; activation refused |
| Combat | Aim Assist / Aimbot | Catalog placeholder; activation refused |
| Combat | Triggerbot | Catalog placeholder; activation refused |
| Combat | AutoTotem | Catalog placeholder; activation refused |
| Combat | AutoCrystal | Catalog placeholder; activation refused |
| Combat | Criticals | Catalog placeholder; activation refused |
| Combat | BowAimbot / Trajectories | Catalog placeholder; activation refused |
| Combat | AutoArmor | Catalog placeholder; activation refused |
| Movement | Speed / BunnyHop | Catalog placeholder; activation refused |
| Movement | Fly / Glide | Catalog placeholder; activation refused |
| Movement | NoFall | Catalog placeholder; activation refused |
| Movement | Jesus / WaterWalk | Catalog placeholder; activation refused |
| Movement | Spider / Step | Catalog placeholder; activation refused |
| Movement | NoSlow / AntiSlow | Catalog placeholder; activation refused |
| Movement | Sprint / AutoSprint | Catalog placeholder; activation refused |
| Render & Visuals | ESP | Catalog placeholder; activation refused |
| Render & Visuals | X-Ray | Catalog placeholder; activation refused |
| Render & Visuals | Tracers | Catalog placeholder; activation refused |
| Render & Visuals | Nametags | Catalog placeholder; activation refused |
| Render & Visuals | Freecam | Catalog placeholder; activation refused |
| Render & Visuals | Fullbright | Catalog placeholder; activation refused |
| Player & Utility | ChestStealer / AutoLoot | Catalog placeholder; activation refused |
| Player & Utility | Scaffold | Catalog placeholder; activation refused |
| Player & Utility | FastEat / FastUse | Catalog placeholder; activation refused |
| Player & Utility | AutoTool / AutoWeapon | Catalog placeholder; activation refused |
| Player & Utility | AutoFish | Catalog placeholder; activation refused |
| Player & Utility | AntiAFK | Catalog placeholder; activation refused |
| Utility (extra) | Ore Pointer | Experimental source backend; requires version-specific runtime verification |

**No feature listed here should be presented as tested or fully functional.** The catalog is UI scaffolding for the requested design; Ore Pointer is the only gameplay-oriented code currently present, and it has not been runtime-tested in this environment.
