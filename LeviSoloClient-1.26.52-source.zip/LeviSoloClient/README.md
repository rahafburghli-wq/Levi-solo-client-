# Levi Solo Client — expanded feature-catalog source kit

A C++ native-mod source project for LeviLaunchroid / LeviLauncher on Minecraft Bedrock for Android. This source targets the version label `1.26.52` (also seen as `26.52` in official changelogs). It packages as a `.levipack` only after the Android native library has been compiled with the Android SDK/NDK, CMake, Ninja, and a compatible game build.

**Important status:** this is not a compiled `.levipack`, and it is not a fully implemented 27-feature hack client. It includes an experimental Ore Pointer backend, a fail-closed session-check prototype, and Mod Menu catalog entries for all 27 features requested. The remaining feature toggles intentionally refuse activation because their gameplay backends are not implemented or tested against a specific Minecraft Bedrock binary. They are listed in the menu as a scaffold, not presented as working cheats.

## Requested module catalog

### Combat
- KillAura / Forcefield
- Aim Assist / Aimbot
- Triggerbot
- AutoTotem
- AutoCrystal
- Criticals
- BowAimbot / Trajectories
- AutoArmor

### Movement
- Speed / BunnyHop
- Fly / Glide
- NoFall
- Jesus / WaterWalk
- Spider / Step
- NoSlow / AntiSlow
- Sprint / AutoSprint

### Render & Visuals
- ESP
- X-Ray
- Tracers
- Nametags
- Freecam
- Fullbright

### Player & Utility
- ChestStealer / AutoLoot
- Scaffold
- FastEat / FastUse
- AutoTool / AutoWeapon
- AutoFish
- AntiAFK

## Single-player safety design

- Feature toggles start OFF.
- The experimental Ore Pointer checks the session guard before scanning, and again on each local-player tick.
- The guard attempts to resolve multiple `ClientInstance` methods associated with world activity, multiplayer, cross-platform multiplayer, and Realms.
- If a required symbol is absent, the hook isn't installed, a check fails, or the session is unknown, the feature refuses to scan.
- The requested catalog entries have no gameplay code; attempts to turn them on are immediately refused and returned to OFF.

**This does not prove multiplayer isolation.** Bedrock's exported symbols and function signatures vary by build, and the guard has not been tested on the target phone/game release against a server, Realm, or LAN world. Do not describe it in a video as multiplayer-proof until those cases have been tested. A native client cannot reliably enforce a promise based solely on its menu label.

## Build requirements

- Android phone/tablet with LeviLaunchroid / LeviLauncher and an official Minecraft Bedrock installation
- Windows build computer with Android SDK, Android NDK 28.2.13676358 or compatible, CMake 3.22+, Ninja, Git, and PowerShell
- Internet connection during CMake configuration to fetch the Preloader SDK and dependencies

From PowerShell in the project directory:

```powershell
$env:ANDROID_HOME = "$env:LOCALAPPDATA\Android\Sdk"
.\scripts\package.ps1 -Abi arm64-v8a
```

The generated `.levipack` is written under the build output folder. The package manifest is configured for the version label you gave (`1.26.52`) and the official changelog label (`26.52`). The manifest patterns are `1.26.52*` and `26.52.*`. LeviLauncher's version-match logic and your installed build should still be checked after import; a manifest match does not guarantee that native game symbols or hooks are compatible.

## Import and test

1. Back up your Minecraft worlds.
2. Build the source on Windows with the NDK installed.
3. Transfer the generated `.levipack` to your Android device.
4. Import it from the LeviLauncher Mods screen and start Minecraft through the launcher.
5. Test only in a throwaway local single-player world first.
6. Confirm that unknown sessions and multiplayer, Realms, and LAN sessions all show a `BLOCKED` state before relying on the restriction.
7. Treat any module other than Ore Pointer as unavailable until a compatible implementation is developed and tested.

## Project map

- `src/mod/SessionGuard.*` — conservative session checks and failure-closed behavior
- `src/mod/OrePointer.*` — experimental ore scanning and overlay
- `src/mod/FeatureCatalog.*` — requested 27-entry categorized menu catalog; unsupported entries are intentionally refused
- `src/mod/SoloClient.*` — mod lifecycle, config, and menu registration
- `CMakeLists.txt`, `scripts/package.ps1`, `manifest.json.in` — native build/package setup
- `FEATURE_MATRIX.md` — explicit implemented-vs-placeholder status
- `BUILD_STATUS.md` — current artifact and runtime verification status
- `BUILD_ON_GITHUB.md` — steps to generate a real `.levipack` using the included Actions workflow
- `.github/workflows/build.yml` — CI package build on GitHub Actions (does not validate game-runtime behavior)

## Why the remaining modules aren't marked working

LeviLauncher exposes lifecycle, menu, hook, and overlay APIs, but most Minecraft Bedrock world/player operations needed for combat, movement, inventory manipulation, camera control, and entity rendering are not a stable cross-version public API. Implementing those modules requires version-specific symbols/wrappers and runtime tests. Adding menu toggles alone is not implementation, so this project refuses activation instead of pretending those features work.
