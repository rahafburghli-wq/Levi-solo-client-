# Build the `.levipack` with GitHub Actions

This source kit is not itself an installable `.levipack`. The package must contain the compiled Android ARM64 native library (`liblevi_solo_client.so`) as well as the manifest and config files. The Android NDK is not available in the environment that created this archive, so the native library has not been built here.

## Steps

1. On GitHub, create a new repository for this source project.
2. Upload the *contents* of the `LeviSoloClient` folder to the repository root. Keep the hidden `.github/workflows/build.yml` file and the `scripts` folder in their original paths.
3. Commit the files to the `main` branch and open the repository's **Actions** tab. Enable Actions if GitHub asks.
4. Select **Build Levi Solo Client** and choose **Run workflow**.
5. When the workflow succeeds, open that run and download the `LeviSoloClient-arm64-levipack` artifact. The artifact should contain the generated `.levipack`.
6. Import the built package in LeviLauncher's native Mods section.

A successful compile only verifies packaging/build compatibility. It does **not** verify the internal Minecraft hooks or the single-player-only restriction. The feature catalog entries other than Ore Pointer are placeholders that intentionally switch back off; Ore Pointer is experimental and is not runtime-tested. Do not present it as a working 27-feature client until those parts are implemented and tested on `1.26.52`.
