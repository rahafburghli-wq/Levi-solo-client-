param(
    [ValidateSet("arm64-v8a", "armeabi-v7a", "all")]
    [string]$Abi = "arm64-v8a",
    [string]$BuildRoot = "build",
    [string]$AndroidPlatform = "android-28",
    [string]$NdkHome = "",
    [string]$Generator = "Ninja"
)
$ErrorActionPreference = "Stop"
$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path

function Resolve-NdkHome {
    if ($NdkHome -and (Test-Path $NdkHome)) { return (Resolve-Path $NdkHome).Path }
    if ($env:ANDROID_HOME) {
        $preferred = Join-Path $env:ANDROID_HOME "ndk/28.2.13676358"
        if (Test-Path $preferred) { return (Resolve-Path $preferred).Path }
        $ndkRoot = Join-Path $env:ANDROID_HOME "ndk"
        if (Test-Path $ndkRoot) {
            $candidate = Get-ChildItem $ndkRoot -Directory | Sort-Object Name -Descending | Select-Object -First 1
            if ($candidate) { return $candidate.FullName }
        }
    }
    if ($env:ANDROID_NDK_HOME -and (Test-Path $env:ANDROID_NDK_HOME)) { return (Resolve-Path $env:ANDROID_NDK_HOME).Path }
    throw "Android NDK not found. Set -NdkHome, ANDROID_NDK_HOME, or ANDROID_HOME."
}

function Generate-Config {
    $dir = Join-Path $repoRoot "$BuildRoot-config"
    cmake -S $repoRoot -B $dir -G $Generator
    if ($LASTEXITCODE -ne 0) { throw "CMake configure for config generator failed" }
    cmake --build $dir --target levi_generate_config
    if ($LASTEXITCODE -ne 0) { throw "Config generation failed" }
    return (Join-Path $dir "generated-config")
}

function Build-ForAbi([string]$TargetAbi, [string]$ConfigDir) {
    $ndk = Resolve-NdkHome
    $toolchain = Join-Path $ndk "build/cmake/android.toolchain.cmake"
    if (-not (Test-Path $toolchain)) { throw "Android NDK toolchain not found: $toolchain" }
    $buildDir = Join-Path $repoRoot "$BuildRoot-$TargetAbi"
    cmake -S $repoRoot -B $buildDir -G $Generator `
        -DCMAKE_TOOLCHAIN_FILE="$toolchain" `
        -DANDROID_ABI="$TargetAbi" `
        -DANDROID_PLATFORM="$AndroidPlatform" `
        -DANDROID_STL="c++_shared" `
        -DLEVI_PACKAGE_CONFIG_DIR="$ConfigDir"
    if ($LASTEXITCODE -ne 0) { throw "CMake configure for $TargetAbi failed" }
    cmake --build $buildDir --target levi_package
    if ($LASTEXITCODE -ne 0) { throw "Package build for $TargetAbi failed" }
}

$configDir = Generate-Config
if ($Abi -eq "all") {
    Build-ForAbi "arm64-v8a" $configDir
    Build-ForAbi "armeabi-v7a" $configDir
} else {
    Build-ForAbi $Abi $configDir
}
Write-Host "Build finished. Inspect the relevant build-* folder for the .levipack. Verify runtime compatibility and test multiplayer blocking before use."
