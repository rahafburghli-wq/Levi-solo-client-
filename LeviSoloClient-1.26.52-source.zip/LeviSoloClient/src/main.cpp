#include "mod/SoloClient.h"
#include <pl/Mod.hpp>
PL_REGISTER_MOD(levi_solo::SoloClient, levi_solo::SoloClient::instance());
