#pragma once

#include <atomic>
#include <string>
#include <pl/Logger.hpp>
#include <pl/memory/Hook.hpp>

namespace levi_solo {

enum class SessionState { Unknown, NoWorld, Multiplayer, SinglePlayer };
struct SessionSnapshot {
    SessionState state = SessionState::Unknown;
    std::string message = "BLOCKED: session not verified";
    [[nodiscard]] bool allowed() const noexcept { return state == SessionState::SinglePlayer; }
};

class SessionGuard {
  public:
    static SessionGuard &instance();
    bool initialize(pl::log::Logger *logger);
    void shutdown();
    [[nodiscard]] SessionSnapshot check() const;

  private:
    using BoolConstMethod = bool (*)(const void *);
    using BoolMethod = bool (*)(void *);
    static bool isWorldActiveDetour(const void *self);
    static void *resolveSymbol(const char *name);

    pl::log::Logger *mLogger{};
    std::atomic<const void *> mClientInstance{nullptr};
    void *mWorldActiveTarget{};
    BoolConstMethod mOriginalWorldActive{};
    BoolConstMethod mIsInMultiplayerGame{};
    BoolConstMethod mIsMultiPlayerClient{};
    BoolConstMethod mIsPrimaryLevelMultiplayer{};
    BoolConstMethod mIsPrimaryLevelCrossPlatformMultiplayer{};
    BoolMethod mIsInRealm{};
    pl::memory::HookHandle mWorldActiveHook;
    std::atomic<bool> mReady{false};
};
} // namespace levi_solo
