#pragma once

#include <string_view>
#include <pl/Config.hpp>

namespace levi_solo {

struct ModConfig {
    int version = 1;
    bool enabled = false;
    int targetOre = 0; // 0=diamond, 1=ancient debris, 2=emerald, 3=gold, 4=iron, 5=lapis, 6=redstone, 7=coal
    int scanRadius = 10;
    int verticalRadius = 8;
    int refreshMs = 500;
};

nlohmann::json makeDefaultConfigJson();
nlohmann::json makeConfigSchemaJson();

} // namespace levi_solo

template <> struct pl::config::Schema<levi_solo::ModConfig> {
    static constexpr std::string_view title = "Levi Solo Client Config";
    static constexpr std::string_view description = "Ore Pointer settings. Runtime multiplayer checks always override enabled state.";

    static constexpr pl::config::FieldSchema field(std::string_view name) {
        if (name == "version") return {.title = "Version", .readOnly = true};
        if (name == "enabled") return {.title = "Enabled", .description = "Ore Pointer module state."};
        if (name == "targetOre") return {.title = "Target Ore", .minimum = 0, .maximum = 7};
        if (name == "scanRadius") return {.title = "Scan Radius", .minimum = 4, .maximum = 32};
        if (name == "verticalRadius") return {.title = "Vertical Radius", .minimum = 4, .maximum = 24};
        if (name == "refreshMs") return {.title = "Refresh Milliseconds", .minimum = 250, .maximum = 2000};
        return {};
    }
};
