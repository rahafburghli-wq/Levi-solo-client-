#include "mod/Config.h"

namespace levi_solo {
nlohmann::json makeDefaultConfigJson() { return pl::config::defaultJson(ModConfig{}); }
nlohmann::json makeConfigSchemaJson() { return pl::config::schema(ModConfig{}); }
} // namespace levi_solo
