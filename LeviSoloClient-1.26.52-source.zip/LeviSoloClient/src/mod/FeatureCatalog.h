#pragma once

#include <pl/Mod.hpp>

namespace levi_solo {

// Registers one Mod Menu entry for each requested client feature. These are
// intentionally non-functional placeholders until a compatible, version-tested
// Bedrock backend exists for each feature. Enabling any placeholder is refused.
bool registerFeatureCatalog(ll::mod::NativeMod &self);
void unregisterFeatureCatalog();

} // namespace levi_solo
