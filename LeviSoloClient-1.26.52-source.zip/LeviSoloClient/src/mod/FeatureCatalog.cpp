#include "mod/FeatureCatalog.h"

#include "mod/SessionGuard.h"

#include <pl/ModMenu.hpp>
#include <array>
#include <string>
#include <string_view>
#include <vector>

namespace levi_solo {
namespace {
struct FeatureSpec {
    std::string_view id;
    std::string_view name;
    std::string_view category;
    std::string_view detail;
};

// Full requested list is represented in the menu. Only features with a tested
// runtime backend should ever be allowed to stay enabled. At this source-kit
// revision, Ore Pointer is the sole experimental backend.
constexpr std::array<FeatureSpec, 27> kFeatures{{
    {"killaura", "KillAura / Forcefield", "Combat", "Automatic nearby entity attacks; backend not implemented."},
    {"aim_assist", "Aim Assist / Aimbot", "Combat", "Targeted view rotation; backend not implemented."},
    {"triggerbot", "Triggerbot", "Combat", "Crosshair-triggered attacks; backend not implemented."},
    {"auto_totem", "AutoTotem", "Combat", "Offhand totem management; backend not implemented."},
    {"auto_crystal", "AutoCrystal", "Combat", "End Crystal combat automation; backend not implemented."},
    {"criticals", "Criticals", "Combat", "Critical-hit movement logic; backend not implemented."},
    {"bow_aimbot", "BowAimbot / Trajectories", "Combat", "Projectile trajectory assist; backend not implemented."},
    {"auto_armor", "AutoArmor", "Combat", "Automatic armor selection; backend not implemented."},

    {"speed", "Speed / BunnyHop", "Movement", "Movement speed modification; backend not implemented."},
    {"fly", "Fly / Glide", "Movement", "Flight and glide control; backend not implemented."},
    {"nofall", "NoFall", "Movement", "Fall-damage prevention; backend not implemented."},
    {"jesus", "Jesus / WaterWalk", "Movement", "Water/lava surface movement; backend not implemented."},
    {"spider_step", "Spider / Step", "Movement", "Climb/step movement; backend not implemented."},
    {"noslow", "NoSlow / AntiSlow", "Movement", "Use/movement slowdown modification; backend not implemented."},
    {"autosprint", "Sprint / AutoSprint", "Movement", "Automatic sprinting; backend not implemented."},

    {"esp", "ESP", "Render & Visuals", "Entity boxes/outlines; backend not implemented."},
    {"xray", "X-Ray", "Render & Visuals", "Ore/block visibility rendering; backend not implemented."},
    {"tracers", "Tracers", "Render & Visuals", "Entity tracer lines; backend not implemented."},
    {"nametags", "Nametags", "Render & Visuals", "Enhanced entity labels; backend not implemented."},
    {"freecam", "Freecam", "Render & Visuals", "Detached camera control; backend not implemented."},
    {"fullbright", "Fullbright", "Render & Visuals", "Maximum brightness; backend not implemented."},

    {"cheststealer", "ChestStealer / AutoLoot", "Player & Utility", "Automatic chest transfer; backend not implemented."},
    {"scaffold", "Scaffold", "Player & Utility", "Automatic block placement underfoot; backend not implemented."},
    {"fastuse", "FastEat / FastUse", "Player & Utility", "Item-use speed modification; backend not implemented."},
    {"autotool", "AutoTool / AutoWeapon", "Player & Utility", "Automatic tool/weapon selection; backend not implemented."},
    {"autofish", "AutoFish", "Player & Utility", "Fishing automation; backend not implemented."},
    {"antiafk", "AntiAFK", "Player & Utility", "AFK-avoidance movement; backend not implemented."},
}};

std::vector<std::string> gRegistered;

std::string moduleIdFor(std::string_view id) {
    return "levi_solo_client.feature." + std::string(id);
}

} // namespace

bool registerFeatureCatalog(ll::mod::NativeMod &self) {
    bool allRegistered = true;
    gRegistered.clear();
    for (const auto &feature : kFeatures) {
        const std::string moduleId = moduleIdFor(feature.id);
        const std::string displayName(feature.name);
        const std::string description = std::string(feature.category) +
            " — Single-player-only client scaffold. " + std::string(feature.detail) +
            " This toggle is refused until a tested backend is available.";

        const bool ok = pl::modmenu::ModuleBuilder(moduleId, displayName)
            .modId(self.getId())
            .description(description)
            .defaultEnabled(false)
            .onToggle([selfPtr = &self, featureId = std::string(feature.id), category = std::string(feature.category)](
                          std::string_view callbackModuleId, bool enabled) {
                if (!enabled) return;

                // Guard first: never treat unknown status as offline play.
                const auto session = SessionGuard::instance().check();
                if (!session.allowed()) {
                    selfPtr->getLogger().warn("Blocked {} module in {} session: {}",
                                          featureId, category, session.message);
                    pl::modmenu::setModuleEnabled(callbackModuleId, false);
                    return;
                }

                // No game-side implementation is shipped for this item yet.
                // Immediately return the UI toggle to OFF, avoiding fake success.
                selfPtr->getLogger().warn("{} is a catalog placeholder; no compatible game backend is installed",
                                      featureId);
                pl::modmenu::setModuleEnabled(callbackModuleId, false);
            })
            .registerModule();

        if (ok) gRegistered.push_back(moduleId);
        else {
            allRegistered = false;
            self.getLogger().warn("Could not register feature catalog item {}", moduleId);
        }
    }
    self.getLogger().info("Feature catalog loaded: {} entries; gameplay placeholders remain OFF",
                          gRegistered.size());
    return allRegistered;
}

void unregisterFeatureCatalog() {
    for (const auto &id : gRegistered) pl::modmenu::unregisterModule(id);
    gRegistered.clear();
}

} // namespace levi_solo
