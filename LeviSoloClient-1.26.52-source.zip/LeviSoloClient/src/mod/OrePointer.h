#pragma once

#include <chrono>
#include <mutex>
#include <string>
#include <pl/Logger.hpp>
#include <pl/memory/Hook.hpp>
#include "mod/Config.h"

namespace levi_solo {

class OrePointer {
  public:
    static OrePointer &instance();
    bool initialize(pl::log::Logger *logger);
    void shutdown();
    void setEnabled(bool enabled);
    void setConfig(const ModConfig &config);

  private:
    using LocalPlayerTickFn = void (*)(void *);
    struct Vec3f { float x{}, y{}, z{}; };
    struct BlockPos { int x{}, y{}, z{}; };
    struct Functions {
        Vec3f (*getPos)(const void *){};
        void *(*getRegion)(const void *){};
        const void *(*getBlock)(void *, const BlockPos &){};
        const void *(*getLegacyBlock)(const void *){};
        const std::string &(*getRawNameId)(const void *){};
    };

    static void *resolveSymbol(const char *name);
    static void localPlayerTickDetour(void *localPlayer);
    void onLocalPlayerTick(void *localPlayer);
    bool resolveFunctions();
    void updateOverlay(const std::string &line1, const std::string &line2 = {});
    void clearOverlay();
    std::string oreName(int id) const;
    bool blockMatches(const void *block, int targetOre, std::string *matchedName) const;

    pl::log::Logger *mLogger{};
    mutable std::mutex mMutex;
    ModConfig mConfig{};
    bool mEnabled{};
    bool mInitialized{};
    bool mFunctionsReady{};
    Functions mFunctions{};
    void *mTickTarget{};
    LocalPlayerTickFn mOriginalTick{};
    pl::memory::HookHandle mTickHook;
    std::chrono::steady_clock::time_point mLastScan{};
    std::chrono::steady_clock::time_point mLastDraw{};
    std::string mStatus{"BLOCKED: not initialized"};
};
} // namespace levi_solo
