#pragma once
#include <optional>
#include <pl/Mod.hpp>
#include "mod/Config.h"

namespace levi_solo {
class SoloClient {
  public:
    static SoloClient &instance();
    SoloClient();
    [[nodiscard]] ll::mod::NativeMod &getSelf() const { return mSelf; }
    bool load();
    bool enable();
    bool disable();
    bool unload();
  private:
    void registerOreModule();
    void applyConfig();
    ll::mod::NativeMod &mSelf;
    ModConfig mConfig{};
    std::optional<pl::config::ConfigFile<ModConfig>> mConfigFile;
    bool mModuleRegistered{};
};
}
