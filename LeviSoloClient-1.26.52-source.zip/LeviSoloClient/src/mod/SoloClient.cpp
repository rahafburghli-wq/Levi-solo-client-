#include "mod/SoloClient.h"
#include "mod/OrePointer.h"
#include "mod/SessionGuard.h"
#include "mod/FeatureCatalog.h"

#include <algorithm>
#include <filesystem>
#include <pl/ModMenu.hpp>
#include <string>

namespace levi_solo {
namespace {
constexpr const char *kModuleId = "levi_solo_client.ore_pointer";
int parseInt(std::string_view value, int fallback) {
    try { return std::stoi(std::string(value)); } catch (...) { return fallback; }
}
}

SoloClient &SoloClient::instance() {
    static SoloClient client;
    return client;
}
SoloClient::SoloClient() : mSelf(*ll::mod::NativeMod::current()) {}

bool SoloClient::load() {
    auto &self = getSelf();
    std::error_code ec;
    std::filesystem::create_directories(self.getDataDir(), ec);
    if (ec) { self.getLogger().error("Cannot create mod data folder: {}", ec.message()); return false; }
    std::filesystem::create_directories(self.getConfigDir(), ec);
    if (ec) { self.getLogger().error("Cannot create mod config folder: {}", ec.message()); return false; }

    mConfigFile.emplace();
    if (!mConfigFile->load()) { self.getLogger().error("Cannot load config"); return false; }
    mConfig = mConfigFile->value();
    mConfig.targetOre = std::clamp(mConfig.targetOre, 0, 7);
    mConfig.scanRadius = std::clamp(mConfig.scanRadius, 4, 32);
    mConfig.verticalRadius = std::clamp(mConfig.verticalRadius, 4, 24);
    mConfig.refreshMs = std::clamp(mConfig.refreshMs, 250, 2000);

    SessionGuard::instance().initialize(&self.getLogger());
    OrePointer::instance().initialize(&self.getLogger());
    OrePointer::instance().setConfig(mConfig);
    OrePointer::instance().setEnabled(false); // always require an explicit toggle after launch
    registerOreModule();
    registerFeatureCatalog(self);
    self.getLogger().info("Levi Solo Client loaded. Ore Pointer is experimental; the requested feature catalog is visible but unimplemented entries are refused.");
    return true;
}

void SoloClient::registerOreModule() {
    using namespace pl::modmenu;
    ModuleBuilder builder(kModuleId, "Ore Pointer — Singleplayer Only");
    builder.modId("levi_solo_client")
        .description("Ore locator for local worlds. Runtime guard blocks multiplayer/Realm or unknown sessions.")
        .defaultEnabled(false)
        .config("targetOre", "Target Ore (0 diamond, 1 debris, 2 emerald, 3 gold, 4 iron, 5 lapis, 6 redstone, 7 coal)", ConfigType::SliderInt, std::to_string(mConfig.targetOre), "0", "7")
        .config("scanRadius", "Horizontal Scan Radius", ConfigType::SliderInt, std::to_string(mConfig.scanRadius), "4", "32")
        .config("verticalRadius", "Vertical Scan Radius", ConfigType::SliderInt, std::to_string(mConfig.verticalRadius), "4", "24")
        .config("refreshMs", "Refresh Interval (ms)", ConfigType::SliderInt, std::to_string(mConfig.refreshMs), "250", "2000")
        .onToggle([this](std::string_view moduleId, bool enabled) {
            // Reject the toggle immediately outside a verified offline world. The tick hook
            // repeats this check, so UI state alone can never authorize a scan.
            if (enabled) {
                const auto session = SessionGuard::instance().check();
                if (!session.allowed()) {
                    getSelf().getLogger().warn("Ore Pointer activation blocked: {}", session.message);
                    mConfig.enabled = false;
                    OrePointer::instance().setEnabled(false);
                    pl::modmenu::setModuleEnabled(moduleId, false);
                    if (mConfigFile) { mConfigFile->value() = mConfig; mConfigFile->save(); }
                    return;
                }
            }
            mConfig.enabled = enabled;
            OrePointer::instance().setConfig(mConfig);
            OrePointer::instance().setEnabled(enabled);
            if (mConfigFile) { mConfigFile->value() = mConfig; mConfigFile->save(); }
        })
        .onConfigChanged([this](std::string_view, std::string_view key, std::string_view value) {
            if (key == "targetOre") mConfig.targetOre = parseInt(value, mConfig.targetOre);
            else if (key == "scanRadius") mConfig.scanRadius = parseInt(value, mConfig.scanRadius);
            else if (key == "verticalRadius") mConfig.verticalRadius = parseInt(value, mConfig.verticalRadius);
            else if (key == "refreshMs") mConfig.refreshMs = parseInt(value, mConfig.refreshMs);
            mConfig.targetOre = std::clamp(mConfig.targetOre, 0, 7);
            mConfig.scanRadius = std::clamp(mConfig.scanRadius, 4, 32);
            mConfig.verticalRadius = std::clamp(mConfig.verticalRadius, 4, 24);
            mConfig.refreshMs = std::clamp(mConfig.refreshMs, 250, 2000);
            OrePointer::instance().setConfig(mConfig);
            if (mConfigFile) { mConfigFile->value() = mConfig; mConfigFile->save(); }
        });
    mModuleRegistered = builder.registerModule();
    if (!mModuleRegistered) getSelf().getLogger().warn("Mod Menu module registration failed");
}

void SoloClient::applyConfig() {
    OrePointer::instance().setConfig(mConfig);
    OrePointer::instance().setEnabled(false);
}

bool SoloClient::enable() {
    getSelf().getLogger().info("Mod enabled; Ore Pointer remains OFF until selected in Mod Menu.");
    applyConfig();
    return true;
}

bool SoloClient::disable() {
    OrePointer::instance().setEnabled(false);
    return true;
}

bool SoloClient::unload() {
    OrePointer::instance().shutdown();
    SessionGuard::instance().shutdown();
    if (mModuleRegistered) pl::modmenu::unregisterModule(kModuleId);
    unregisterFeatureCatalog();
    mModuleRegistered = false;
    mConfigFile.reset();
    return true;
}
} // namespace levi_solo
