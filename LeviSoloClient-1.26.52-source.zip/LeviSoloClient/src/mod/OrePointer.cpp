#include "mod/OrePointer.h"
#include "mod/SessionGuard.h"

#include <algorithm>
#include <cmath>
#include <dlfcn.h>
#include <limits>
#include <pl/ModMenu.hpp>

namespace levi_solo {
namespace {
constexpr const char *kModuleId = "levi_solo_client.ore_pointer";
constexpr int kMaxRadius = 32;
constexpr int kMaxVertical = 24;

void *minecraftHandle() {
    static void *handle = []() -> void * {
#ifdef RTLD_NOLOAD
        return dlopen("libminecraftpe.so", RTLD_NOW | RTLD_NOLOAD);
#else
        return nullptr;
#endif
    }();
    return handle;
}

bool finitePos(float v) { return std::isfinite(v) && std::abs(v) < 30'000'000.0f; }
} // namespace

OrePointer &OrePointer::instance() {
    static OrePointer pointer;
    return pointer;
}

void *OrePointer::resolveSymbol(const char *name) {
    if (!name || !*name) return nullptr;
    if (void *p = dlsym(RTLD_DEFAULT, name)) return p;
    if (void *handle = minecraftHandle()) return dlsym(handle, name);
    return nullptr;
}

bool OrePointer::resolveFunctions() {
    if (!mFunctions.getPos) {
        mFunctions.getPos = reinterpret_cast<decltype(mFunctions.getPos)>(resolveSymbol("_ZNK5Actor6getPosEv"));
        if (!mFunctions.getPos) mFunctions.getPos = reinterpret_cast<decltype(mFunctions.getPos)>(resolveSymbol("_ZNK5Actor11getPositionEv"));
    }
    if (!mFunctions.getRegion)
        mFunctions.getRegion = reinterpret_cast<decltype(mFunctions.getRegion)>(resolveSymbol("_ZNK5Actor9getRegionEv"));
    if (!mFunctions.getBlock) {
        mFunctions.getBlock = reinterpret_cast<decltype(mFunctions.getBlock)>(resolveSymbol("_ZNK11BlockSource8getBlockERK8BlockPos"));
        if (!mFunctions.getBlock) mFunctions.getBlock = reinterpret_cast<decltype(mFunctions.getBlock)>(resolveSymbol("_ZN11BlockSource8getBlockERK8BlockPos"));
    }
    if (!mFunctions.getLegacyBlock)
        mFunctions.getLegacyBlock = reinterpret_cast<decltype(mFunctions.getLegacyBlock)>(resolveSymbol("_ZNK5Block14getLegacyBlockEv"));
    if (!mFunctions.getRawNameId) {
        mFunctions.getRawNameId = reinterpret_cast<decltype(mFunctions.getRawNameId)>(resolveSymbol("_ZNK11BlockLegacy12getRawNameIdEv"));
        if (!mFunctions.getRawNameId) mFunctions.getRawNameId = reinterpret_cast<decltype(mFunctions.getRawNameId)>(resolveSymbol("_ZNK11BlockLegacy11getTypeNameEv"));
    }
    mFunctionsReady = mFunctions.getPos && mFunctions.getRegion && mFunctions.getBlock &&
                      mFunctions.getLegacyBlock && mFunctions.getRawNameId;
    return mFunctionsReady;
}

bool OrePointer::initialize(pl::log::Logger *logger) {
    mLogger = logger;
    mInitialized = false;
    mEnabled = false;
    resolveFunctions();
    mTickTarget = resolveSymbol("_ZN11LocalPlayer10normalTickEv");
    if (!mTickTarget) mTickTarget = resolveSymbol("_ZN11LocalPlayer4tickEv");
    if (!mTickTarget) {
        if (mLogger) mLogger->warn("Ore Pointer: LocalPlayer tick symbol not found; feature stays off");
        return false;
    }
    mTickHook = pl::memory::HookHandle(mTickTarget,
        reinterpret_cast<void *>(&OrePointer::localPlayerTickDetour),
        reinterpret_cast<void **>(&mOriginalTick), pl::memory::HookPriority::Normal);
    mInitialized = mTickHook.installed() && mOriginalTick;
    if (mLogger) {
        if (mInitialized) mLogger->info("Ore Pointer tick hook installed; module defaults OFF");
        else mLogger->warn("Ore Pointer hook failed; feature stays off");
    }
    return mInitialized;
}

void OrePointer::shutdown() {
    mEnabled = false;
    clearOverlay();
    mTickHook.reset();
    mOriginalTick = nullptr;
    mTickTarget = nullptr;
    mInitialized = false;
    if (mLogger) mLogger->info("Ore Pointer shut down");
}

void OrePointer::setEnabled(bool enabled) {
    std::lock_guard lock(mMutex);
    mEnabled = enabled && mInitialized;
    if (!mEnabled) clearOverlay();
}

void OrePointer::setConfig(const ModConfig &config) {
    std::lock_guard lock(mMutex);
    mConfig = config;
    mConfig.targetOre = std::clamp(mConfig.targetOre, 0, 7);
    mConfig.scanRadius = std::clamp(mConfig.scanRadius, 4, kMaxRadius);
    mConfig.verticalRadius = std::clamp(mConfig.verticalRadius, 4, kMaxVertical);
    mConfig.refreshMs = std::clamp(mConfig.refreshMs, 250, 2000);
}

void OrePointer::localPlayerTickDetour(void *localPlayer) {
    auto &pointer = instance();
    const auto original = pointer.mOriginalTick;
    if (original) original(localPlayer);
    pointer.onLocalPlayerTick(localPlayer);
}

std::string OrePointer::oreName(int id) const {
    switch (id) {
        case 0: return "diamond_ore";
        case 1: return "ancient_debris";
        case 2: return "emerald_ore";
        case 3: return "gold_ore";
        case 4: return "iron_ore";
        case 5: return "lapis_ore";
        case 6: return "redstone_ore";
        case 7: return "coal_ore";
        default: return "diamond_ore";
    }
}

bool OrePointer::blockMatches(const void *block, int targetOre, std::string *matchedName) const {
    if (!block || !mFunctions.getLegacyBlock || !mFunctions.getRawNameId) return false;
    try {
        const void *legacy = mFunctions.getLegacyBlock(block);
        if (!legacy) return false;
        const std::string &name = mFunctions.getRawNameId(legacy);
        const std::string target = oreName(targetOre);
        if (name.find(target) == std::string::npos) return false;
        if (matchedName) *matchedName = name;
        return true;
    } catch (...) {
        return false;
    }
}

void OrePointer::updateOverlay(const std::string &line1, const std::string &line2) {
    using namespace pl::modmenu;
    std::vector<DrawCommand> commands;
    DrawCommand background{};
    background.type = DrawCommandType::RectFilled;
    background.x = 18.0f; background.y = 82.0f; background.w = 420.0f;
    background.h = line2.empty() ? 38.0f : 62.0f;
    background.color = 0xB0101010u;
    commands.push_back(background);

    DrawCommand primary{};
    primary.type = DrawCommandType::Text;
    primary.x = 28.0f; primary.y = 90.0f; primary.size = 18.0f;
    primary.color = line1.find("BLOCKED") == 0 ? 0xFFFF7777u : 0xFF88FFAAu;
    primary.text = line1;
    commands.push_back(primary);
    if (!line2.empty()) {
        DrawCommand secondary{};
        secondary.type = DrawCommandType::Text;
        secondary.x = 28.0f; secondary.y = 116.0f; secondary.size = 16.0f;
        secondary.color = 0xFFFFFFFFu;
        secondary.text = line2;
        commands.push_back(secondary);
    }
    submitDrawCommands(kModuleId, commands);
}

void OrePointer::clearOverlay() {
    const std::vector<pl::modmenu::DrawCommand> empty;
    pl::modmenu::submitDrawCommands(kModuleId, empty);
}

void OrePointer::onLocalPlayerTick(void *localPlayer) {
    if (!localPlayer) return;

    ModConfig config;
    bool enabled;
    {
        std::lock_guard lock(mMutex);
        config = mConfig;
        enabled = mEnabled;
    }
    if (!enabled) return;

    const auto now = std::chrono::steady_clock::now();
    const auto session = SessionGuard::instance().check();
    if (!session.allowed()) {
        if (mLastDraw.time_since_epoch().count() == 0 ||
            std::chrono::duration_cast<std::chrono::milliseconds>(now - mLastDraw).count() >= 250) {
            mLastDraw = now;
            updateOverlay(session.message);
        }
        return; // Critical: never scan unless the session guard explicitly allows it.
    }

    if (std::chrono::duration_cast<std::chrono::milliseconds>(now - mLastScan).count() < config.refreshMs) return;
    mLastScan = now;
    if (!resolveFunctions()) {
        updateOverlay("BLOCKED: required game symbols missing");
        return;
    }

    Vec3f player{};
    void *region = nullptr;
    try {
        player = mFunctions.getPos(localPlayer);
        region = mFunctions.getRegion(localPlayer);
    } catch (...) {
        updateOverlay("BLOCKED: game API call failed");
        return;
    }
    if (!region || !finitePos(player.x) || !finitePos(player.y) || !finitePos(player.z)) {
        updateOverlay("BLOCKED: world data unavailable");
        return;
    }

    const int radius = std::clamp(config.scanRadius, 4, kMaxRadius);
    const int vertical = std::clamp(config.verticalRadius, 4, kMaxVertical);
    const int bx = static_cast<int>(std::floor(player.x));
    const int by = static_cast<int>(std::floor(player.y));
    const int bz = static_cast<int>(std::floor(player.z));
    float bestSq = std::numeric_limits<float>::max();
    BlockPos best{};
    std::string bestName;
    bool found = false;

    for (int dx = -radius; dx <= radius; ++dx) {
        for (int dz = -radius; dz <= radius; ++dz) {
            const int horizontalSq = dx * dx + dz * dz;
            if (horizontalSq > radius * radius) continue;
            for (int dy = -vertical; dy <= vertical; ++dy) {
                const float distSq = static_cast<float>(horizontalSq + dy * dy);
                if (distSq >= bestSq) continue;
                const BlockPos pos{bx + dx, by + dy, bz + dz};
                const void *block = nullptr;
                try { block = mFunctions.getBlock(region, pos); }
                catch (...) { updateOverlay("BLOCKED: block read failed"); return; }
                std::string matched;
                if (blockMatches(block, config.targetOre, &matched)) {
                    bestSq = distSq; best = pos; bestName = std::move(matched); found = true;
                }
            }
        }
    }

    if (!found) {
        updateOverlay("SOLO CHECKS PASSED (untested)", "No nearby " + oreName(config.targetOre));
    } else {
        const int dist = static_cast<int>(std::sqrt(bestSq));
        updateOverlay("SOLO CHECKS PASSED (untested)",
            bestName + " at " + std::to_string(best.x) + ", " + std::to_string(best.y) + ", " +
            std::to_string(best.z) + "  |  " + std::to_string(dist) + " blocks");
    }
}
} // namespace levi_solo
