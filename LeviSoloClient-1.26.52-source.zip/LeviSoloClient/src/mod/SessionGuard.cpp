#include "mod/SessionGuard.h"
#include <dlfcn.h>

namespace levi_solo {
namespace {
void *minecraftHandle() {
    static void *handle = []() -> void * {
#ifdef RTLD_NOLOAD
        return dlopen("libminecraftpe.so", RTLD_NOW | RTLD_NOLOAD);
#else
        return nullptr;
#endif
    }();
    return handle;
}
} // namespace

SessionGuard &SessionGuard::instance() {
    static SessionGuard guard;
    return guard;
}

void *SessionGuard::resolveSymbol(const char *name) {
    if (!name || !*name) return nullptr;
    if (void *p = dlsym(RTLD_DEFAULT, name)) return p;
    if (void *handle = minecraftHandle()) return dlsym(handle, name);
    return nullptr;
}

bool SessionGuard::initialize(pl::log::Logger *logger) {
    mLogger = logger;
    mReady.store(false, std::memory_order_release);
    mClientInstance.store(nullptr, std::memory_order_release);
    mWorldActiveTarget = resolveSymbol("_ZNK14ClientInstance13isWorldActiveEv");
    mIsInMultiplayerGame = reinterpret_cast<BoolConstMethod>(resolveSymbol("_ZNK14ClientInstance19isInMultiplayerGameEv"));
    mIsMultiPlayerClient = reinterpret_cast<BoolConstMethod>(resolveSymbol("_ZNK14ClientInstance19isMultiPlayerClientEv"));
    mIsPrimaryLevelMultiplayer = reinterpret_cast<BoolConstMethod>(resolveSymbol("_ZNK14ClientInstance25isPrimaryLevelMultiplayerEv"));
    mIsPrimaryLevelCrossPlatformMultiplayer = reinterpret_cast<BoolConstMethod>(resolveSymbol("_ZNK14ClientInstance38isPrimaryLevelCrossPlatformMultiplayerEv"));
    mIsInRealm = reinterpret_cast<BoolMethod>(resolveSymbol("_ZN14ClientInstance9isInRealmEv"));

    if (!mWorldActiveTarget || !mIsInMultiplayerGame || !mIsMultiPlayerClient ||
        !mIsPrimaryLevelMultiplayer || !mIsPrimaryLevelCrossPlatformMultiplayer || !mIsInRealm) {
        if (mLogger) mLogger->warn("Solo guard fail-closed: required ClientInstance symbols missing");
        return false;
    }

    mWorldActiveHook = pl::memory::HookHandle(
        mWorldActiveTarget, reinterpret_cast<void *>(&SessionGuard::isWorldActiveDetour),
        reinterpret_cast<void **>(&mOriginalWorldActive), pl::memory::HookPriority::Normal);
    const bool ready = mWorldActiveHook.installed() && mOriginalWorldActive;
    mReady.store(ready, std::memory_order_release);
    if (mLogger) {
        if (ready) mLogger->info("Solo guard installed; unresolved and multiplayer sessions stay blocked");
        else mLogger->warn("Solo guard hook unavailable; Ore Pointer stays blocked");
    }
    return ready;
}

void SessionGuard::shutdown() {
    mReady.store(false, std::memory_order_release);
    mWorldActiveHook.reset();
    mClientInstance.store(nullptr, std::memory_order_release);
    mOriginalWorldActive = nullptr;
    if (mLogger) mLogger->info("Solo guard shut down");
}

bool SessionGuard::isWorldActiveDetour(const void *self) {
    auto &guard = instance();
    if (self) guard.mClientInstance.store(self, std::memory_order_release);
    const auto original = guard.mOriginalWorldActive;
    return original ? original(self) : false;
}

SessionSnapshot SessionGuard::check() const {
    if (!mReady.load(std::memory_order_acquire) || !mOriginalWorldActive || !mIsInMultiplayerGame ||
        !mIsMultiPlayerClient || !mIsPrimaryLevelMultiplayer ||
        !mIsPrimaryLevelCrossPlatformMultiplayer || !mIsInRealm) {
        return {SessionState::Unknown, "BLOCKED: offline state cannot be verified"};
    }
    const void *client = mClientInstance.load(std::memory_order_acquire);
    if (!client) return {SessionState::Unknown, "BLOCKED: waiting for session state"};

    try {
        if (!mOriginalWorldActive(client)) return {SessionState::NoWorld, "BLOCKED: no active world"};
        const bool multiplayer = mIsInMultiplayerGame(client) || mIsMultiPlayerClient(client) ||
            mIsPrimaryLevelMultiplayer(client) || mIsPrimaryLevelCrossPlatformMultiplayer(client) ||
            mIsInRealm(const_cast<void *>(client));
        if (multiplayer) return {SessionState::Multiplayer, "BLOCKED: multiplayer/Realm session"};
    } catch (...) {
        return {SessionState::Unknown, "BLOCKED: session check failed"};
    }
    return {SessionState::SinglePlayer, "SOLO CHECKS PASSED (untested on this build)"};
}
} // namespace levi_solo
