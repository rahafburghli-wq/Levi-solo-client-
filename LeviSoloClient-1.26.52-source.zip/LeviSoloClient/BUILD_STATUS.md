# Build status — Levi Solo Client

- Target version label: `1.26.52` (official Bedrock changelog label: `26.52`).
- Source project and Android package script are included.
- No installable `.levipack` was compiled in this environment: Android NDK/SDK are not installed, and the build needs those tools plus dependency downloads.
- Do not rename the source ZIP to `.levipack`; LeviLauncher packages must contain a compiled Android native library referenced by `manifest.json`.
- The feature catalog currently registers the 27 requested names as placeholders and refuses activation because compatible gameplay backends are not implemented. Ore Pointer is experimental source code, not runtime-verified.
- The single-player checks are fail-closed by design, but have not been validated on the reported game build. Test in a throwaway local world, then verify servers, Realms, and LAN are blocked before representing the client as single-player-only.

The repository includes `.github/workflows/build.yml` for building an ARM64 package with GitHub Actions after the source is placed in a repository. The resulting artifact still needs runtime testing before it should be distributed.
